/* JS Document */

/******************************

[Table of Contents]

1. Vars and Inits
2. Init Menu
3. InitQty


******************************/

$(document).ready(function()
{
   "use strict";

   /* 

   1. Vars and Inits

   */

   var menu = $('.menu');
   var burger = $('.hamburger');
   var menuActive = false;

   $(window).on('resize', function()
   {
      setTimeout(function()
      {
         $(window).trigger('resize.px.parallax');
      }, 375);
   });

   initMenu();
   initQty();

   /* 

   2. Init Menu

   */

   function initMenu()
   {
      if(menu.length)
      {
         if($('.hamburger').length)
         {
            burger.on('click', function()
            {
               if(menuActive)
               {
                  closeMenu();
               }
               else
               {
                  openMenu();

                  $(document).one('click', function cls(e)
                  {
                     if($(e.target).hasClass('menu_mm'))
                     {
                        $(document).one('click', cls);
                     }
                     else
                     {
                        closeMenu();
                     }
                  });
               }
            });
         }
      }
   }

   function openMenu()
   {
      menu.addClass('active');
      menuActive = true;
   }

   function closeMenu()
   {
      menu.removeClass('active');
      menuActive = false;
   }

   /* 

   3. Init Qty

   */

   function initQty()
   {
      if($('.product_quantity').length)
      {
         var qtys = $('.product_quantity');

         qtys.each(function()
         {
            var qty = $(this);
            var sub = qty.find('.qty_sub');
            console.log(sub.text());
            var add = qty.find('.qty_add');
            console.log(add.text());
            var num = qty.find('.product_num');
            console.log(num.text());
            var total = $('.product_total').text();
            console.log(total);
            var original;
            var newValue;
            var aaa;
            var bbb;
            var ccc;
            var ddd;
            
            //var text = $().text();
            sub.on('click', function()//- 버튼 누를때
            {
               original = parseFloat(qty.find('.product_num').text());
               console.log(original);
               
               if(original > 1)
                  {
                     console.log(original);
                     newValue = original - 1;

                     ddd = parseFloat($(num).text());
                     console.log(ddd);
                     aaa = $("#testId").text();//가격
                     console.log(aaa);
                     bbb = ccc//총금액
                     console.log(bbb);
                     ccc = bbb - aaa ;

                     console.log(ccc);
                     $("#testID1").text(ccc);
                  }
               num.text(newValue);

                    

               
               /*qty.find('.product_total').text(ccc);*/
            });

            add.on('click', function()//+는 건드릴게 없음
            {
               original = parseFloat(qty.find('.product_num').text());
               newValue = original + 1;
               num.text(newValue);

               aaa = ($(num).text());// 수량
               console.log(aaa);
               bbb = $("#testId").text();//가격
               console.log(bbb);
               ccc = bbb * aaa ;
               console.log(ccc);
               $("#testID1").text(ccc);
            });
         }); 
         
         
      }
   }

});