package bean;

public class StarDTO {
	private String id;
	private int starnum;
	private int top;
	private int under;
	private int shoes;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getStarnum() {
		return starnum;
	}
	public void setStarnum(int starnum) {
		this.starnum = starnum;
	}
	public int getTop() {
		return top;
	}
	public void setTop(int top) {
		this.top = top;
	}
	public int getUnder() {
		return under;
	}
	public void setUnder(int under) {
		this.under = under;
	}
	public int getShoes() {
		return shoes;
	}
	public void setShoes(int shoes) {
		this.shoes = shoes;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
