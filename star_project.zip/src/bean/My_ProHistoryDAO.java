package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class My_ProHistoryDAO {
	DBConnectionMgr mgr;
	
	public  My_ProHistoryDAO() {
		mgr = DBConnectionMgr.getInstance();
	}
		
	    public void insert(String pro, String size,int price, int amount, String id, String date) throws Exception {
	        
	        //1.2단계를 해주는 DBconnectinMgr 객체 필요
	        Connection con = mgr.getConnection();
	        
	        
	        
	        //3단계 sql문 결정
	     /* String sql = "insert into my_cart value(?,?,?,?)"; */
	        String sql = "insert into my_prohistory values(?,?,?,?,?,?)";
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setString(1, pro);
	        ps.setString(2, size);
	        ps.setInt(3, price);
	        ps.setInt(4, amount);
	        ps.setString(5, id);
	        ps.setString(6, date);
	        
	       
	        
	        //4단계 sql문 전달요청
	        ps.executeUpdate();
	        mgr.freeConnection(con,ps);
	     }
	    
}
