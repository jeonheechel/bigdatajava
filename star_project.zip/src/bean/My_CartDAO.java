package bean;


import java.sql.*;
import java.util.ArrayList;







public class My_CartDAO {
	DBConnectionMgr mgr;
	public My_CartDAO() {
		
		mgr = DBConnectionMgr.getInstance();//한개밖에 못만든다
	}
	public void insert(My_CartDTO dto) throws Exception {
		
		//1.2단계를 해주는 DBconnectinMgr 객체 필요
		Connection con = mgr.getConnection();
		
		
		
		//3단계 sql문 결정
		String sql = "insert into my_cart value(?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,dto.getPro());
		ps.setString(2,dto.getSize());
		ps.setInt(3,dto.getPrice());
		ps.setInt(4,dto.getAmount());
		ps.setString(5,dto.getId());
	
		
		//4단계 sql문 전달요청
		ps.executeUpdate();
		
		mgr.freeConnection(con,ps);
		
	}
	

	public My_CartDTO select(String iD) throws Exception {
		
		//1.2단계를 해주는 DBconnectinMgr 객체 필요
		Connection con = mgr.getConnection();
		
		
		
		//3단계 sql문 결정
		String sql = "select * from my_cart where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,iD);
		
		
		//4단계 sql문 전달요청
		ResultSet rs =  ps.executeQuery();
		
		My_CartDTO  dto2 = null;
		while(rs.next()) {
			dto2 = new My_CartDTO();
			String pro = rs.getString(1);
			String size = rs.getString(2);
			String price = rs.getString(3);
			String amount = rs.getString(4);
			String id = rs.getString(5); 
			
			dto2.setPro(pro);
			dto2.setSize(size);
			dto2.setPrice(Integer.parseInt(price));
			dto2.setAmount(Integer.parseInt(amount));
			dto2.setId(id); 
			
			
		}
		return dto2;
		
	}
	
	public void update(My_CartDTO dto) throws Exception {
		
		//1.2단계를 해주는 DBconnectinMgr 객체 필요
		Connection con = mgr.getConnection();
		
		
		
		//3단계 sql문 결정
		String sql = "update my_cart set  pro= ?, size= ?, price= ?, amount= ?, id= ?     where id= ?  AND pro=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,dto.getPro());
		ps.setString(2,dto.getSize());
		ps.setInt(3,dto.getPrice());
		ps.setInt(4,dto.getAmount());
		ps.setString(5,dto.getId());
		ps.setString(6,dto.getId());
		ps.setString(7,dto.getPro());
		
		
		
		
		//4단계 sql문 전달요청
		ps.executeUpdate();
		mgr.freeConnection(con,ps);
	}
	
public void deleteAll(String id) throws Exception {
		
		//1.2단계를 해주는 DBconnectinMgr 객체 필요
		Connection con = mgr.getConnection();
		
		
		
		//3단계 sql문 결정
		String sql = "delete  from my_cart where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,id);
		
		
		//4단계 sql문 전달요청
		ps.executeUpdate();
		mgr.freeConnection(con,ps);
	}
public void delete(String id, String pro) throws Exception {
	
	//1.2단계를 해주는 DBconnectinMgr 객체 필요
	Connection con = mgr.getConnection();
	
	
	
	//3단계 sql문 결정
	String sql = "delete  from my_cart where id=? AND pro=?";
	PreparedStatement ps = con.prepareStatement(sql);
	ps.setString(1,id);
	ps.setString(2,pro);
	
	
	//4단계 sql문 전달요청
	ps.executeUpdate();
	mgr.freeConnection(con,ps);
}

	public ArrayList<My_CartDTO> selectAll(String iD) throws Exception {
		ArrayList<My_CartDTO> list = new ArrayList<My_CartDTO>(); 
		
		//1.2단계를 해주는 DBconnectinMgr 객체 필요
		Connection con = mgr.getConnection();
		
		
		
		//3단계 sql문 결정
		String sql = "select * from my_cart where id=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1,iD);
		
		
		//4단계 sql문 전달요청
		ResultSet rs =  ps.executeQuery();
		My_CartDTO  dto2 = null;
		while(rs.next()) {
			dto2 = new My_CartDTO();
			String pro = rs.getString(1);
			String size = rs.getString(2);
			String price = rs.getString(3);
			String amount = rs.getString(4);
			String id = rs.getString(5);
			
			dto2.setPro(pro);
			dto2.setSize(size);
			dto2.setPrice(Integer.parseInt(price));
			dto2.setAmount(Integer.parseInt(amount));
			dto2.setId(id);
			
			
			
			list.add(dto2);
			
		}
		return list;
	}
		
		
		
		
	

}
