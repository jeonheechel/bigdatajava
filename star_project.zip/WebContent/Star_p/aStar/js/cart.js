/* JS Document */

/******************************

[Table of Contents]

1. Vars and Inits
2. Init Menu
3. InitQty


******************************/

$(document).ready(function()
{
	"use strict";

	/* 

	1. Vars and Inits

	*/

	var menu = $('.menu');
	var burger = $('.hamburger');
	var menuActive = false;

	$(window).on('resize', function()
	{
		setTimeout(function()
		{
			$(window).trigger('resize.px.parallax');
		}, 375);
	});

	initMenu();
	initQty();

	/* 

	2. Init Menu

	*/

	function initMenu()
	{
		if(menu.length)
		{
			if($('.hamburger').length)
			{
				burger.on('click', function()
				{
					if(menuActive)
					{
						closeMenu();
					}
					else
					{
						openMenu();

						$(document).one('click', function cls(e)
						{
							if($(e.target).hasClass('menu_mm'))
							{
								$(document).one('click', cls);
							}
							else
							{
								closeMenu();
							}
						});
					}
				});
			}
		}
	}

	function openMenu()
	{
		menu.addClass('active');
		menuActive = true;
	}

	function closeMenu()
	{
		menu.removeClass('active');
		menuActive = false;
	}

	/* 

	3. Init Qty

	*/

	function initQty()
	{
		if($('.product_quantity').length)
		{
			var qtys = $('.product_quantity');

			qtys.each(function()
			{
				var qty = $(this);
				var sub = qty.find('.qty_sub');
				console.log(sub.text());
				var add = qty.find('.qty_add');
				console.log(add.text());
				var num = qty.find('.product_num');
				console.log(num.text());
				var total = $('.product_total').text();
				console.log(total);
				var original;
				var newValue;
				var aaa;
				var bbb;
				var ccc;
				sub.on('click', function()
				{
					original = parseFloat(qty.find('.product_num').text());
					console.log(original);
					
					if(original > 0)
						{
							newValue = original - 1;
						}
					num.text(newValue);



					aaa = parseFloat($(num).text());// 수량
					console.log(aaa);
					bbb = parseFloat($('.product_price').text());//가격*수량=총금액
					console.log(bbb);
					ccc = aaa * bbb;
					/*qty.find('.product_total').text(ccc);*/
					console.log(ccc);
					$('.product_total').val(sum.value);
				});

				add.on('click', function()
				{
					original = parseFloat(qty.find('.product_num').text());
					newValue = original + 1;
					num.text(newValue);

					aaa = parseFloat($('.product_num').text());
					console.log(aaa);
					bbb = parseFloat($('.product_price').text());
					console.log(bbb);
					ccc = aaa * bbb;
					console.log(ccc);
					$('.product_total').text(ccc);
				});
			});
			
			/*var qtys = $('.product_total');

			qtys.each(function()
			{
				var qty = $(this);
				var sub = qty.find('.qty_sub');
				var add = qty.find('.qty_add');
				var num = qty.find('.product_num');
				var total = qty.find('.pro_total');
				var original;
				var newValue;
				var aaa;
				var bbb;
				var ccc;
				sub.on('click', function()
				{
					original = parseFloat(qty.find('.product_num').text());
					if(original > 0)
						{
							newValue = original - 1;
						}
						
						
						aaa = parseFloat(qty.find('.product_num').text());
						bbb = parseFloat(qty.find('product_price').text());
						ccc = aaa * bbb;
						total.text(ccc);
					
				});

				add.on('click', function()
				{
					original = parseFloat(qty.find('.product_num').text());
					newValue = original + 1;
					num.text(newValue);

					aaa = parseFloat(qty.find('.product_total').text());
					bbb = parseFloat(qty.find('.product_price').text());
					ccc = aaa * bbb;
					qty.find('.product_total').text(ccc);
				});
			});*/
		}
	}

});