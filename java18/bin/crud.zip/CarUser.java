package crud;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;









public class CarUser {
		
	

	public static void main(String[] args) {
		
		
		//insert
//		Scanner sc = new Scanner(System.in);
//		System.out.print("아이디:");
//		String id = sc.next();
//		System.out.print("이름:");
//		String name = sc.next();
//		System.out.print("컨텐츠:");
//		String content = sc.next();
//		System.out.print("가격:");
//		String price = sc.next();
//		
//		CarDAO dao = new CarDAO();
//		CarDTO dto = new CarDTO();
//		dto.setId(id);
//		dto.setName(name);
//		dto.setContent(content);
//		dto.setPrice(price);
//		dao.insert(dto);
		
		
		
		
		
		
		
		//select
		
//		CarDAO dao = new CarDAO();
//		String Id = JOptionPane.showInputDialog("검색할 id입력");
//		ArrayList list = dao.select(Id);
//		
//		
//		
//		for (int i = 0; i < list.size(); i++) {
//			CarDTO dto = (CarDTO)list.get(i);
//			System.out.println(dto.getId());
//			System.out.println(dto.getName());
//			System.out.println(dto.getContent());
//			System.out.println(dto.getPrice());
//			System.out.println();
//			
//		}
	
		
		
		
		
		
		//selectAll
//		CarDAO dao = new CarDAO();
//		ArrayList list = dao.selectAll();
//		
//		
//		for (int i = 0; i < list.size(); i++) {//전체 출력하기
//			CarDTO dto = (CarDTO)list.get(i);
//			System.out.println(dto.getId());
//			System.out.println(dto.getName());
//			System.out.println(dto.getContent());
//			System.out.println(dto.getPrice());
//			System.out.println();
//			
//		}
		
		
		
		
		
		
		
		//update
//		Scanner sc = new Scanner(System.in);
//		System.out.print("아이디:");
//		String id =sc.next();
//		System.out.print("가격:");
//		String price =sc.next();
//	
//		
//		CarDAO dao = new CarDAO();
//		CarDTO dto = new CarDTO();
//		dto.setId(id);
//		dto.setPrice(price);
//		dao.update(dto);
		
		
		
		//delete
//		Scanner sc = new Scanner(System.in);
//		System.out.print("아이디:");
//		String id =sc.next();
//		
//		CarDAO dao = new CarDAO();
//		CarDTO dto = new CarDTO();
//		dto.setId(id);
//		dao.delete(dto);
		
		
		
		
		
		
	}

}
