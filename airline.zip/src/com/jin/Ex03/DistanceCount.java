package com.jin.Ex03;

public enum DistanceCount {
	january,february,march,
	april,may,june,
	july,august,september,
	october,november,december

}
