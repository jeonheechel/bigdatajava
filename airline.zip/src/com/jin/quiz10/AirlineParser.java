package com.jin.quiz10;

import org.apache.hadoop.io.Text;

public class AirlineParser {
	private String year;
	private int month;
	private int cancelled;
	
	final int NONCANCELLED = 0;
	
	public AirlineParser() {}
	public AirlineParser(Text txt) {
		String []airData = txt.toString().split(",");
		year = airData[0];
		month = Integer.parseInt(airData[1]);
		cancelled = Integer.parseInt(airData[21]);
	}
	
	public void setYear(String year) {
		this.year = year;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public void setCancelled(int cancelled) {
		this.cancelled = cancelled;
	}
	public String getYear() {
		return year;
	}
	public int getMonth() {
		return month;
	}
	public int getCancelled() {
		return cancelled;
	}
}
