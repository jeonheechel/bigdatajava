package com.jin.Ex02;

public enum DistanceCount {
	zeroCnt,nomZeroCnt

}
