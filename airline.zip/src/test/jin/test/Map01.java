package test.jin.test;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Map01 extends Mapper<LongWritable, Text, Text, IntWritable>  {
	
	//multiple output 실습
	
	/*@Override
	public void map(Text key, Text value, Context output){
		override를 쓰는 이유 : 재정의 시 오타를 방지하기 위해서라도 사용, 
		  override없이 오타가 발생하면 내부 메소드를 새로 만든 것과 같음(위의 Mapper의 메소드 재정의가 아니여서 오류발생위험)
	}*/
	
	@Override		
	public void map(LongWritable key, Text value, Context output) throws IOException, InterruptedException{
		AirlineParser ap = new AirlineParser(value);
		
		//CarrierDelay 0보다 크면 실행
		if(ap.getCarrierDelay()>0){
			
			output.write(new Text(ap.getUniqueCarrier()+"_"+ap.getTailNum()),new IntWritable(ap.getCarrierDelay()));
		}else{
			//CarrierDelay 0보다 작으면 실행
			output.write(new Text(ap.getUniqueCarrier()+"_"+ap.getTailNum()), new IntWritable(AirlineParser.NONDELAY));
		}
		
		//실제 넘어가는 데이터
		//dep:uc, arr:uc
	}
	
	
}

