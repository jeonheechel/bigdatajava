package test.jin.test;

import org.apache.hadoop.io.Text;

public class AirlineParser {
	
	private String UniqueCarrier;
	private String TailNum;
	private int CarrierDelay;
	
	public static final int NONDELAY = 0;
	
	public AirlineParser() {	}
	
	private int getDigitFromStr(String str, int defaultDigit){
		if("NA".equalsIgnoreCase(str)) return defaultDigit;
		//else else가 없어도 위에 if에 해당하면 return하며 종료되기 때문에
			return Integer.parseInt(str);
	}
	
	public AirlineParser(Text value) {
		String[] airData = value.toString().split(",");
		//항공사 코드
		UniqueCarrier = airData[8];
		//항공기 등록 번호(비행기 고리 날개 쪽에 표기)
		TailNum = airData[10];
		//항공사 지연 시간, 분으로 표기
		CarrierDelay = getDigitFromStr(airData[24], NONDELAY);
	}

	public String getUniqueCarrier() {
		return UniqueCarrier;
	}

	public void setUniqueCarrier(String uniqueCarrier) {
		UniqueCarrier = uniqueCarrier;
	}

	public String getTailNum() {
		return TailNum;
	}

	public void setTailNum(String tailNum) {
		TailNum = tailNum;
	}

	public int getCarrierDelay() {
		return CarrierDelay;
	}

	public void setCarrierDelay(int carrierDelay) {
		CarrierDelay = carrierDelay;
	}
	
	
	
}
